/* ------------------------------------------------------------------ */
/* Decimal 32-bit format module                                       */
/* ------------------------------------------------------------------ */
/* Copyright (c) IBM Corporation, 2000, 2003.  All rights reserved.   */
/*                                                                    */
/* This software is made available under the terms of the IBM         */
/* alphaWorks License Agreement (distributed with this software as    */
/* alphaWorks-License.txt).  Your use of this software indicates      */
/* your acceptance of the terms and conditions of that Agreement.     */
/*                                                                    */
/* The description and User's Guide ("The decNumber C Library") for   */
/* this software is included in the package as decNumber.pdf.  This   */
/* document is also available in HTML, together with specifications,  */
/* testcases, and Web links, at: http://www2.hursley.ibm.com/decimal  */
/*                                                                    */
/* Please send comments, suggestions, and corrections to the author:  */
/*   mfc@uk.ibm.com                                                   */
/*   Mike Cowlishaw, IBM Fellow                                       */
/*   IBM UK, PO Box 31, Birmingham Road, Warwick CV34 5JL, UK         */
/* ------------------------------------------------------------------ */
/* This module comprises the routines for decimal32 format numbers.   */
/* Conversions are supplied to and from decNumber and String.         */
/*                                                                    */
/* No arithmetic routines are included; decNumber provides these.     */
/*                                                                    */
/* Error handling is the same as decNumber (qv.).                     */
/* ------------------------------------------------------------------ */
#include <string.h>           // [for memset/memcpy]
#include <stdio.h>            // [for printf]

#define  DECNUMDIGITS  7      // we need decNumbers with space for 7
#include "decNumber.h"        // base number library
#include "decNumberLocal.h"   // decNumber local types, etc.
#include "decimal32.h"        // our primary include
#include "decDPD.h"           // lookup tables

/* Private utility routines [shared] */
void decDensePackCoeff(decNumber *, uByte *, Int, Int);
void decDenseUnpackCoeff(uByte *, Int, decNumber *, Int);

#if DECTRACE || DECCHECK
void decimal32Show(decimal32 *);   // for debug
void decNumberShow(decNumber *);   // ..
#endif

/* Useful macro */
// Clear a structure (e.g., a decNumber)
#define DEC_clear(d) memset(d, 0, sizeof(*d))

/* ------------------------------------------------------------------ */
/* decimal32FromNumber -- convert decNumber to decimal32              */
/*                                                                    */
/*   ds is the target decimal32                                       */
/*   dn is the source number (assumed valid)                          */
/*   set is the context, used only for reporting errors               */
/*                                                                    */
/* The set argument is used only for status reporting and for the     */
/* rounding mode (used if the coefficient is more than DECIMAL32_Pmax */
/* digits or an overflow is detected).  If the exponent is out of the */
/* valid range then Overflow or Underflow will be raised.             */
/* After Underflow a subnormal result is possible.                    */
/*                                                                    */
/* DEC_Clamped is set if the number has to be 'folded down' to fit,   */
/* by reducing its exponent and multiplying the coefficient by a      */
/* poer of ten, or the exponent on a zero had to be clampde.          */
/* ------------------------------------------------------------------ */
decimal32 * decimal32FromNumber(decimal32 *d32, decNumber *dn,
                              decContext *set) {
  uInt status=0;                   // status accumulator
  Int pad=0;                       // coefficient pad digits
  decNumber  dw;                   // work
  decContext dc;                   // ..
  uByte isneg=dn->bits&DECNEG;     // non-0 if original sign set
  uInt comb, exp;                  // work

  // If the number is finite, and has too many digits, or the exponent
  // could be out of range then we reduce the number under the
  // appropriate constraints
  if (!(dn->bits&DECSPECIAL)) {                   // not a special value
    Int ae=dn->exponent+dn->digits-1;             // adjusted exponent
    if (dn->digits>DECIMAL32_Pmax                 // too many digits
      || ae>DECIMAL32_Emax                        // likely overflow
      || ae<DECIMAL32_Emin) {                     // likely underflow
      decContextDefault(&dc, DEC_INIT_DECIMAL32); // [no traps]
      dc.round=set->round;                        // use supplied rounding
      decNumberPlus(&dw, dn, &dc);                // (round and check)
      // [this changes -0 to 0, but it will be restored below]
      status|=dc.status;                          // save status
      dn=&dw;                                     // use the work number
      }
    // [this could have pushed number to Infinity or zero, so this
    // rounding must be done before we generate the decimal32]
    }


  DEC_clear(d32);                                 // clean the target
  if (dn->bits&DECSPECIAL) {                      // a special value
    uByte top;                                    // work
    if (dn->bits&DECINF) top=DECIMAL_Inf;
     else {                                       // sNaN or qNaN
      uByte *b;
      for (b=d32->bytes+1; b<d32->bytes+DECIMAL32_Bytes; b++) *b=0xff;
      if (dn->bits&DECNAN) top=DECIMAL_NaN;
       else top=DECIMAL_sNaN;
      isneg=0;
      }
    d32->bytes[0]=top;
    }
   else if (ISZERO(dn)) {                         // a zero
    // set and clamp exponent
    if (dn->exponent<-DECIMAL32_Bias) {
      exp=0;
      status|=DEC_Clamped;
      }
     else {
      exp=dn->exponent+DECIMAL32_Bias;            // bias exponent
      if (exp>DECIMAL32_Ehigh) {                  // top clamp
        exp=DECIMAL32_Ehigh;
        status|=DEC_Clamped;
        }
      }
    comb=(exp>>3) & 0x18;                         // combination field
    d32->bytes[0]=comb<<2;
    exp&=0x3f;                                    // remaining exponent bits
    decimal32SetExpCon(d32, exp);
    }
   else {                          // non-zero finite number
    uInt msd;                      // work

    // we have a dn that fits, but it may need to be padded
    exp=(uInt)(dn->exponent+DECIMAL32_Bias);      // bias exponent

    if (exp>DECIMAL32_Ehigh) {                    // fold-down case
      pad=exp-DECIMAL32_Ehigh;
      exp=DECIMAL32_Ehigh;                        // [to maximum]
      status|=DEC_Clamped;
      }

    decDensePackCoeff(dn, d32->bytes, sizeof(d32->bytes), pad);

    // save and clear the top digit
    msd=((unsigned)d32->bytes[1]>>4);
    d32->bytes[1] &=0x0f;
    // create the combination field
    if (msd>=8) comb=0x18 | (msd & 0x01) | ((exp>>5) & 0x06);
     else comb=(msd & 0x07) | ((exp>>3) & 0x18);
    d32->bytes[0]=comb<<2;
    exp&=0x3f;                                    // remaining exponent bits
    decimal32SetExpCon(d32, exp);
    }

  if (isneg) decimal32SetSign(d32, 1);
  if (status!=0) decContextSetStatus(set, status); // pass on status

  //decimal32Show(d32);
  return d32;
  } // decimal32FromNumber

/* ------------------------------------------------------------------ */
/* decimal32ToNumber -- convert decimal32 to decNumber                */
/*   d32 is the source decimal32                                      */
/*   dn is the target number, with appropriate space                  */
/* No error is possible.                                              */
/* Note that a NaN can get sign=1 from this route                     */
/* ------------------------------------------------------------------ */
decNumber * decimal32ToNumber(decimal32 *d32, decNumber *dn) {
  uInt top=d32->bytes[0]&0x7f;     // top byte, less sign bit
  decNumberZero(dn)     ;          // clean target
  // set the sign if negative
  if (decimal32Sign(d32)) dn->bits=DECNEG;

  if (top>=0x78) {                 // is a special
    if ((top&0x7c)==(DECIMAL_Inf&0x7c)) dn->bits|=DECINF;
    else if ((top&0x7e)==(DECIMAL_NaN&0x7e)) dn->bits|=DECNAN;
    else dn->bits|=DECSNAN;
    dn->digits=1;                  // as per decNumber specification
    }
   else {                          // have a finite number
    uInt comb=top>>2;              // combination field
    uInt msd;                      // coefficient MSD
    uInt exp;                      // exponent
    Int bunches;                   // coefficient bunches to convert
    decimal32 wk;                  // working copy, if needed

    if (comb>=0x18) {
      msd=8+(comb & 0x01);
      exp=(comb & 0x06)<<5;        // MSBs
      }
     else {
      msd=comb & 0x07;
      exp=(comb & 0x18)<<3;
      }
    dn->exponent=exp+decimal32ExpCon(d32)-DECIMAL32_Bias; // remove bias

    // get the coefficient
    bunches=DECIMAL32_Pmax/3;      // assume MSD is 0
    if (msd!=0)     {              // coefficient has leading non-0 digit
      // make a copy of the decimal32, with an extra bunch which has
      // the top digit ready for conversion
      wk=*d32;                     // take a copy
      wk.bytes[0]=0;               // clear all but coecon
      wk.bytes[1]&=0x0f;           // ..
      wk.bytes[1]|=(msd<<4);       // and prefix MSD
      bunches++;                   // and account for the extra
      d32=&wk;                     // use the work copy
      }
    decDenseUnpackCoeff(d32->bytes, sizeof(d32->bytes), dn, bunches);
    }
  return dn;
  } // decimal32ToNumber

/* ------------------------------------------------------------------ */
/* to-scientific-string -- conversion to numeric string               */
/* to-engineering-string -- conversion to numeric string              */
/*                                                                    */
/*   decimal32ToString(d32, string);                                  */
/*   decimal32ToEngString(d32, string);                               */
/*                                                                    */
/*  d32 is the decimal32 format number to convert                     */
/*  string is the string where the result will be laid out            */
/*                                                                    */
/*  string must be at least 24 characters                             */
/*                                                                    */
/*  No error is possible, and no status can be set.                   */
/* ------------------------------------------------------------------ */
char * decimal32ToString(decimal32 *d32, char *string){
  decNumber dn;                         // work
  decimal32ToNumber(d32, &dn);
  decNumberToString(&dn, string);
  return string;
  } // DecSingleToString

char * decimal32ToEngString(decimal32 *d32, char *string){
  decNumber dn;                         // work
  decimal32ToNumber(d32, &dn);
  decNumberToEngString(&dn, string);
  return string;
  } // DecSingleToEngString

/* ------------------------------------------------------------------ */
/* to-number -- conversion from numeric string                        */
/*                                                                    */
/*   decimal32FromString(result, string, set);                        */
/*                                                                    */
/*  result  is the decimal32 format number which gets the result of   */
/*          the conversion                                            */
/*  *string is the character string which should contain a valid      */
/*          number (which may be a special value)                     */
/*  set     is the context                                            */
/*                                                                    */
/* The context is supplied to this routine is used for error handling */
/* (setting of status and traps), etc., as for decNumberFromString.   */
/* If an error occurs, the result will be a valid decimal32.          */
/* ------------------------------------------------------------------ */
decimal32 * decimal32FromString(decimal32 *result, char *string,
                                decContext *set) {
  decContext dc;                             // work
  decNumber dn;                              // ..

  decContextDefault(&dc, DEC_INIT_DECIMAL32); // no traps, please

  decNumberFromString(&dn, string, &dc);
  decimal32FromNumber(result, &dn, &dc);     // will round if needed
  if (dc.status!=0) {                        // something happened
    decContextSetStatus(set, dc.status);     // .. pass it on
    }
  return result;
  } // decimal32FromString

/* ================================================================== */
/* Private utility routines                                           */
/* ================================================================== */

/* ------------------------------------------------------------------ */
/* decDensePackCoeff -- densely pack coefficient into DPD form        */
/*                                                                    */
/*   dn is the source number (assumed valid)                          */
/*   bytes is the target's byte array                                 */
/*   len is length of target format's byte array                      */
/*   pad is the number of 0 digits to add on the right (normally 0)   */
/*                                                                    */
/* The coefficient must be known small enough to fit, and is filled   */
/* in from the right (least significant first).  Note that the full   */
/* coefficient is copied, including the leading 'odd' digit.  This    */
/* digit is retrieved and packed into the combination field by the    */
/* caller.                                                            */
/*                                                                    */
/* pad is used for 'fold-down' padding.                               */
/*                                                                    */
/* No error is possible.                                              */
/* ------------------------------------------------------------------ */
void decDensePackCoeff(decNumber *dn, uByte *bytes, Int len, Int pad) {
  Int  j, n, cut;             // work
  Unit dig, temp;             // current digit
  Int  digits=dn->digits;     // digit counter
  uInt bcd;                   // 0-999 BCD accumulator
  uInt dpd;                   // densely packed decimal value
  Unit  *inu, in;             // -> current input unit
  uByte *bout;                // -> current output byte

  /* densely pack the coefficient into the byte array, starting from
     the right (optionally padded) */
  bout=&bytes[len-1];              // rightmost result byte for phase
  if (pad==0) {
    j=0;                           // three-counter
    n=0;                           // output bunch counter
    }
   else {                          // padding...
    n=pad/3;                       // whole bunches skipped
    j=pad%3;                       // odd digits skipped
    bout-=(10*n)/8;                // adjust start point to suit
    bcd=0;                         // may be oring in
    }
  for (inu=dn->lsu; ; inu++) {     // over each digit, from lsu
    in=*inu;
    for (cut=0; cut<DECDPUN; cut++) {
      #if DECDPUN<=4
        temp=(Unit)((unsigned)(in*6554)>>16);
        dig=(Unit)(in-X10(temp));
        in=temp;
      #else
        dig=in%10;
        in=in/10;
      #endif
      j++; digits--;
      if (j==1) bcd=dig;
       else if (j==2)  bcd+=(dig<<4);
       else /* j==3 */ bcd+=(dig<<8);
      if (j==3 || digits==0) {     // bunch is now complete
        j=0;                       // clear bunch counter
        // write bunch (bcd) to byte array
        dpd=BCD2DPD[bcd];
        switch (n & 0x03) {        // phase 0-3
          case 0:
            *bout=(uByte)dpd;      // [top 2 bits truncated]
            bout--;
            *bout=(uByte)(dpd>>8);
            break;
          case 1:
            *bout|=(uByte)(dpd<<2);
            bout--;
            *bout=(uByte)(dpd>>6);
            break;
          case 2:
            *bout|=(uByte)(dpd<<4);
            bout--;
            *bout=(uByte)(dpd>>4);
            break;
          case 3:
            *bout|=(uByte)(dpd<<6);
            bout--;
            *bout=(uByte)(dpd>>2);
            bout--;
            *bout=0;     // [unnecessary if array precleared]
            break;
          }/*switch*/
        if (digits==0) return;     // all done
        n++;
        } // j=3
      } // cut
    } // inu
  } // decDensePackCoeff

/* ------------------------------------------------------------------ */
/* decDenseUnpackCoeff -- unpack a format's coefficient               */
/*                                                                    */
/*   byte is the source's byte array                                  */
/*   len is length of the source's byte array                         */
/*   dn is the target number, with 7, 16, or 34-digit space.          */
/*   bunches is the number of DPD groups in the decNumber (2, 5, or   */
/*      11, or 3, 6, or 12 if there is a group for the leading 'odd'  */
/*      digit)                                                        */
/*                                                                    */
/* (This routine works on a copy of the number, if necessary, where   */
/* an extra 10-bit group is prefixed to the coefficient continuation  */
/* to hold the most significant digit if the latter is non-0.)        */
/*                                                                    */
/* dn->digits is set, but not the sign or exponent.                   */
/* No error is possible [the redundant 888 codes are allowed].        */
/* ------------------------------------------------------------------ */
void decDenseUnpackCoeff(uByte *bytes, Int len, decNumber *dn, Int bunches) {
  uInt  dpd, bcd;                  // collector for 10 bits; BCD result
  Int   n;                         // counter
  uByte *bin;                      // -> current input byte
  Unit  *uout=dn->lsu;             // -> current output unit
  Unit  out=0;                     // accumulator
  Int   cut=0;                     // power of ten in current unit
  uInt  nibble;                    // work
  Unit  *last=uout;                // will be unit containing msd

  // Expand the densely-packed integer, right to left
  bin=&bytes[len-1];               // next input byte to use
  for (n=0; n<bunches; n++) {      // N bunches of 10 bits
    // assemble the 10 bits
    switch (n & 0x03) {            // phase 0-3
      case 0:
        dpd=*bin;
        bin--;
        dpd|=(*bin & 0x03)<<8;
        break;
      case 1:
        dpd=(unsigned)*bin>>2;
        bin--;
        dpd|=(*bin & 0x0F)<<6;
        break;
      case 2:
        dpd=(unsigned)*bin>>4;
        bin--;
        dpd|=(*bin & 0x3F)<<4;
        break;
      case 3:
        dpd=(unsigned)*bin>>6;
        bin--;
        dpd|=(*bin)<<2;
        bin--;
        break;
      } /*switch*/
    if (dpd==0) {                  // fastpath [e.g., leading zeros]
      cut+=3;
      for (;cut>=DECDPUN;) {
        cut-=DECDPUN;
        *uout=out;
        uout++;
        out=0;
        }
      continue;
      }

    bcd=DPD2BCD[dpd];              // convert 10 bits to 12 bits BCD
    // now split the 3 BCD nibbles into bytes, and accumulate into units
    nibble=bcd & 0x000f;
    if (nibble) {
      last=uout;
      out+=(Unit)(nibble*powers[cut]);
      }
    cut++;
    if (cut==DECDPUN) {*uout=out; uout++; cut=0; out=0;}
    nibble=bcd & 0x00f0;
    if (nibble) {
      nibble>>=4;
      last=uout;
      out+=(Unit)(nibble*powers[cut]);
      }
    cut++;
    if (cut==DECDPUN) {*uout=out; uout++; cut=0; out=0;}
    nibble=bcd & 0x0f00;
    if (nibble) {
      nibble>>=8;
      last=uout;
      out+=(Unit)(nibble*powers[cut]);
      }
    cut++;
    if (cut==DECDPUN) {*uout=out; uout++; cut=0; out=0;}
    } // n
  if (cut!=0) *uout=out;                     // write out final unit
  // here, last points to the most significant unit with digits
  dn->digits=(last-dn->lsu)*DECDPUN;         // floor of digits
  for (cut=0; cut<DECDPUN; cut++) {
    if (*last<powers[cut]) break;
    dn->digits++;
    }
  if (dn->digits==0) dn->digits++;           // 0 has one digit
  return;
  } //decDenseUnpackCoeff


#if DECTRACE || DECCHECK
/* ------------------------------------------------------------------ */
/* decimal32Show -- display a single in hexadecimal [debug aid]       */
/*   d32 -- the number to show                                        */
/* ------------------------------------------------------------------ */
// Also shows sign/cob/expconfields extracted
void decimal32Show(decimal32 *d32) {
  char buf[DECIMAL32_Bytes*2+1];
  Int i, j;
  j=0;
  for (i=0; i<DECIMAL32_Bytes; i++) {
    sprintf(&buf[j], "%02x", d32->bytes[i]);
    j=j+2;
    }
  printf(" D32> %s [S:%d Cb:%02x E:%d]\n", buf,
         decimal32Sign(d32), decimal32Comb(d32), decimal32ExpCon(d32));
  } // decimal32Show
#endif
