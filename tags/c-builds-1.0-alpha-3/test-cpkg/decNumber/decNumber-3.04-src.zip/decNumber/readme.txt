This is the readme.txt for the decNumber package.
-------------------------------------------------

This package includes the files:

  *  readme.txt (this file)

  *  alphaWorks-License.txt (the 90-day trial license)

     Note: a commercial license for this code is also available by
     following the 'License this technology' link from the alphaWorks
     page: http://www.alphaWorks.ibm.com/tech/decnumber

  *  decNumber.pdf (documentation)

  *  The .c and .h file for each module in the package (see
     documentation), decDPD.h (used by decimal32), and
     decNumberLocal.h (local definitions)

  *  The .c files for each of the examples (example1.c through
     example6.c)

These files are made available under the terms of the IBM alphaWorks
License Agreement (in the file alphaWorks-License.txt), unless you have
agreed different licensing terms with IBM.  Your use of this software or
any related documentation indicates your acceptance of the terms and
conditions of that Agreement.


To check the package
--------------------

  Please read the license and documentation before using this package.

  1. Compile and link example1.c, decNumber.c, and decContext.c
     For example:

       gcc -o example1 example1.c decNumber.c decContext.c

     Note: If your compiler does not provide stdint.h or if your C
     compiler does not handle line comments (// ...), then see the
     User's Guide section in the documentation for further information
     (including a suitable minimal stdint.h).

  2. Run example1 with two numeric arguments, for example:

       example1 1.23 1.27

     this should display:

       1.23 + 1.27 => 2.50

  3. Similarly, try the other examples, at will.

     Example 5 requires decimal64.c and decimal32.c in addition to the
       core modules.
     Example 6 requires decPacked.c in addition to the core modules.

