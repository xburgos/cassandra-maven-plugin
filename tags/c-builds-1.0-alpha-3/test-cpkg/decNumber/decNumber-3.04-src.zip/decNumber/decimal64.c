/* ------------------------------------------------------------------ */
/* Decimal 64-bit format module                                       */
/* ------------------------------------------------------------------ */
/* Copyright (c) IBM Corporation, 2000, 2003.  All rights reserved.   */
/*                                                                    */
/* This software is made available under the terms of the IBM         */
/* alphaWorks License Agreement (distributed with this software as    */
/* alphaWorks-License.txt).  Your use of this software indicates      */
/* your acceptance of the terms and conditions of that Agreement.     */
/*                                                                    */
/* The description and User's Guide ("The decNumber C Library") for   */
/* this software is included in the package as decNumber.pdf.  This   */
/* document is also available in HTML, together with specifications,  */
/* testcases, and Web links, at: http://www2.hursley.ibm.com/decimal  */
/*                                                                    */
/* Please send comments, suggestions, and corrections to the author:  */
/*   mfc@uk.ibm.com                                                   */
/*   Mike Cowlishaw, IBM Fellow                                       */
/*   IBM UK, PO Box 31, Birmingham Road, Warwick CV34 5JL, UK         */
/* ------------------------------------------------------------------ */
/* This module comprises the routines for decimal64 format numbers.   */
/* Conversions are supplied to and from decNumber and String.         */
/*                                                                    */
/* No arithmetic routines are included; decNumber provides these.     */
/*                                                                    */
/* Error handling is the same as decNumber (qv.).                     */
/* ------------------------------------------------------------------ */
#include <string.h>           // [for memset/memcpy]
#include <stdio.h>            // [for printf]

#define  DECNUMDIGITS 16      // we need decNumbers with space for 16
#include "decNumber.h"        // base number library
#include "decNumberLocal.h"   // decNumber local types, etc.
#include "decimal64.h"        // our primary include

/* Utility routines [from decimal32.c] */
extern void decDensePackCoeff(decNumber *, uByte *, Int, Int);
extern void decDenseUnpackCoeff(uByte *, Int, decNumber *, Int);

#if DECTRACE || DECCHECK
void decimal64Show(decimal64 *);   // for debug
void decNumberShow(decNumber *);   // ..
#endif

/* Useful macro */
// Clear a structure (e.g., a decNumber)
#define DEC_clear(d) memset(d, 0, sizeof(*d))

/* ------------------------------------------------------------------ */
/* decimal64FromNumber -- convert decNumber to decimal64              */
/*                                                                    */
/*   ds is the target decimal64                                       */
/*   dn is the source number (assumed valid)                          */
/*   set is the context, used only for reporting errors               */
/*                                                                    */
/* The set argument is used only for status reporting and for the     */
/* rounding mode (used if the coefficient is more than DECIMAL64_Pmax */
/* digits or an overflow is detected).  If the exponent is out of the */
/* valid range then Overflow or Underflow will be raised.             */
/* After Underflow a subnormal result is possible.                    */
/*                                                                    */
/* DEC_Clamped is set if the number has to be 'folded down' to fit,   */
/* by reducing its exponent and multiplying the coefficient by a      */
/* poer of ten, or the exponent on a zero had to be clampde.          */
/* ------------------------------------------------------------------ */
decimal64 * decimal64FromNumber(decimal64 *d64, decNumber *dn,
                              decContext *set) {
  uInt status=0;                   // status accumulator
  Int pad=0;                       // coefficient pad digits
  decNumber  dw;                   // work
  decContext dc;                   // ..
  uByte isneg=dn->bits&DECNEG;     // non-0 if original sign set
  uInt comb, exp;                  // work

  // If the number is finite, and has too many digits, or the exponent
  // could be out of range then we reduce the number under the
  // appropriate constraints
  if (!(dn->bits&DECSPECIAL)) {                   // not a special value
    Int ae=dn->exponent+dn->digits-1;             // adjusted exponent
    if (dn->digits>DECIMAL64_Pmax                 // too many digits
      || ae>DECIMAL64_Emax                        // likely overflow
      || ae<DECIMAL64_Emin) {                     // likely underflow
      decContextDefault(&dc, DEC_INIT_DECIMAL64); // [no traps]
      dc.round=set->round;                        // use supplied rounding
      decNumberPlus(&dw, dn, &dc);                // (round and check)
      // [this changes -0 to 0, but it will be restored below]
      status|=dc.status;                          // save status
      dn=&dw;                                     // use the work number
      }
    // [this could have pushed number to Infinity or zero, so this
    // rounding must be done before we generate the decimal64]
    }

  DEC_clear(d64);                                 // clean the target
  if (dn->bits&DECSPECIAL) {                      // a special value
    uByte top;                                    // work
    if (dn->bits&DECINF) top=DECIMAL_Inf;
     else {                                       // sNaN or qNaN
      uByte *b;
      for (b=d64->bytes+1; b<d64->bytes+DECIMAL64_Bytes; b++) *b=0xff;
      if (dn->bits&DECNAN) top=DECIMAL_NaN;
       else top=DECIMAL_sNaN;
      isneg=0;
      }
    d64->bytes[0]=top;
    }
   else if (ISZERO(dn)) {                         // a zero
    // set and clamp exponent
    if (dn->exponent<-DECIMAL64_Bias) {
      exp=0;
      status|=DEC_Clamped;
      }
     else {
      exp=dn->exponent+DECIMAL64_Bias;            // bias exponent
      if (exp>DECIMAL64_Ehigh) {                  // top clamp
        exp=DECIMAL64_Ehigh;
        status|=DEC_Clamped;
        }
      }
    comb=(exp>>5) & 0x18;                         // combination field
    d64->bytes[0]=comb<<2;
    exp&=0xff;                                    // remaining exponent bits
    decimal64SetExpCon(d64, exp);
    }
   else {                          // non-zero finite number
    uInt msd;                      // work

    // we have a dn that fits, but it may need to be padded
    exp=(uInt)(dn->exponent+DECIMAL64_Bias);      // bias exponent

    if (exp>DECIMAL64_Ehigh) {                    // fold-down case
      pad=exp-DECIMAL64_Ehigh;
      exp=DECIMAL64_Ehigh;                        // [to maximum]
      status|=DEC_Clamped;
      }

    decDensePackCoeff(dn, d64->bytes, sizeof(d64->bytes), pad);

    // save and clear the top digit
    msd=((unsigned)d64->bytes[1]>>2) & 0x0f;
    d64->bytes[1] &=0x03;
    // create the combination field
    if (msd>=8) comb=0x18 | (msd & 0x01) | ((exp>>7) & 0x06);
     else comb=(msd & 0x07) | ((exp>>5) & 0x18);
    d64->bytes[0]=comb<<2;
    exp&=0xff;                                    // remaining exponent bits
    decimal64SetExpCon(d64, exp);
    }

  if (isneg) decimal64SetSign(d64, 1);
  if (status!=0) decContextSetStatus(set, status); // pass on status

  //decimal64Show(d64);
  return d64;
  } // decimal64FromNumber

/* ------------------------------------------------------------------ */
/* decimal64ToNumber -- convert decimal64 to decNumber                */
/*   d64 is the source decimal64                                      */
/*   dn is the target number, with appropriate space                  */
/* No error is possible.                                              */
/* Note that a NaN can get sign=1 from this route                     */
/* ------------------------------------------------------------------ */
decNumber * decimal64ToNumber(decimal64 *d64, decNumber *dn) {
  uInt top=d64->bytes[0]&0x7f;     // top byte, less sign bit
  decNumberZero(dn)     ;          // clean target
  // set the sign if negative
  if (decimal64Sign(d64)) dn->bits=DECNEG;

  if (top>=0x78) {                 // is a special
    if ((top&0x7c)==(DECIMAL_Inf&0x7c)) dn->bits|=DECINF;
    else if ((top&0x7e)==(DECIMAL_NaN&0x7e)) dn->bits|=DECNAN;
    else dn->bits|=DECSNAN;
    dn->digits=1;                  // as per decNumber specification
    }
   else {                          // have a finite number
    uInt comb=top>>2;              // combination field
    uInt msd;                      // coefficient MSD
    uInt exp;                      // exponent
    Int bunches;                   // coefficient bunches to convert
    decimal64 wk;                  // working copy, if needed

    if (comb>=0x18) {
      msd=8+(comb & 0x01);
      exp=(comb & 0x06)<<7;        // MSBs
      }
     else {
      msd=comb & 0x07;
      exp=(comb & 0x18)<<5;
      }
    dn->exponent=exp+decimal64ExpCon(d64)-DECIMAL64_Bias; // remove bias

    // get the coefficient
    bunches=DECIMAL64_Pmax/3;      // assume MSD is 0
    if (msd!=0)     {              // coefficient has leading non-0 digit
      // make a copy of the decimal64, with an extra bunch which has
      // the top digit ready for conversion
      wk=*d64;                     // take a copy
      wk.bytes[0]=0;               // clear all but coecon
      wk.bytes[1]&=0x03;           // ..
      wk.bytes[1]|=(msd<<2);       // and prefix MSD
      bunches++;                   // and account for the extra
      d64=&wk;                     // use the work copy
      }
    decDenseUnpackCoeff(d64->bytes, sizeof(d64->bytes), dn, bunches);
    }
  return dn;
  } // decimal64ToNumber

/* ------------------------------------------------------------------ */
/* to-scientific-string -- conversion to numeric string               */
/* to-engineering-string -- conversion to numeric string              */
/*                                                                    */
/*   decimal64ToString(d64, string);                                  */
/*   decimal64ToEngString(d64, string);                               */
/*                                                                    */
/*  d64 is the decimal64 format number to convert                     */
/*  string is the string where the result will be laid out            */
/*                                                                    */
/*  string must be at least 24 characters                             */
/*                                                                    */
/*  No error is possible, and no status can be set.                   */
/* ------------------------------------------------------------------ */
char * decimal64ToString(decimal64 *d64, char *string){
  decNumber dn;                         // work
  decimal64ToNumber(d64, &dn);
  decNumberToString(&dn, string);
  return string;
  } // DecSingleToString

char * decimal64ToEngString(decimal64 *d64, char *string){
  decNumber dn;                         // work
  decimal64ToNumber(d64, &dn);
  decNumberToEngString(&dn, string);
  return string;
  } // DecSingleToEngString

/* ------------------------------------------------------------------ */
/* to-number -- conversion from numeric string                        */
/*                                                                    */
/*   decimal64FromString(result, string, set);                        */
/*                                                                    */
/*  result  is the decimal64 format number which gets the result of   */
/*          the conversion                                            */
/*  *string is the character string which should contain a valid      */
/*          number (which may be a special value)                     */
/*  set     is the context                                            */
/*                                                                    */
/* The context is supplied to this routine is used for error handling */
/* (setting of status and traps), etc., as for decNumberFromString.   */
/* If an error occurs, the result will be a valid decimal64.          */
/* ------------------------------------------------------------------ */
decimal64 * decimal64FromString(decimal64 *result, char *string,
                                decContext *set) {
  decContext dc;                             // work
  decNumber dn;                              // ..

  decContextDefault(&dc, DEC_INIT_DECIMAL64); // no traps, please

  decNumberFromString(&dn, string, &dc);
  decimal64FromNumber(result, &dn, &dc);      // will round if needed
  if (dc.status!=0) {                        // something happened
    decContextSetStatus(set, dc.status);     // .. pass it on
    }
  return result;
  } // decimal64FromString

#if DECTRACE || DECCHECK
/* ------------------------------------------------------------------ */
/* decimal64Show -- display a single in hexadecimal [debug aid]       */
/*   d64 -- the number to show                                        */
/* ------------------------------------------------------------------ */
// Also shows sign/cob/expconfields extracted
void decimal64Show(decimal64 *d64) {
  char buf[DECIMAL64_Bytes*2+1];
  Int i, j;
  j=0;
  for (i=0; i<DECIMAL64_Bytes; i++) {
    sprintf(&buf[j], "%02x", d64->bytes[i]);
    j=j+2;
    }
  printf(" D64> %s [S:%d Cb:%02x E:%d]\n", buf,
         decimal64Sign(d64), decimal64Comb(d64), decimal64ExpCon(d64));
  } // decimal64Show
#endif
