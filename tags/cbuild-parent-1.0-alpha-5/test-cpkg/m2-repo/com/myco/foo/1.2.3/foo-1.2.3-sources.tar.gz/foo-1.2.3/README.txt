This is just a simple placeholder

This project is used for testing the cbuilds Plugins
and is installed by org.codehaus.mojo/cbuilds/test-cpkg/test-harvest
